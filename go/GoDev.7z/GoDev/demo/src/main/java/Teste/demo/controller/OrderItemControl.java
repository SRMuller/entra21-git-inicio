package Teste.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Teste.demo.entidades.OrderItens;
import Teste.demo.service.OrderItemService;

@RestController
@RequestMapping("/orderItem")
public class OrderItemControl {

	@Autowired
	private OrderItemService service;

	@PostMapping
	public OrderItens insert(@RequestBody OrderItens orderItens) {
		return service.insert(orderItens);
	}

	@GetMapping("/{id}")
	public OrderItens read(@PathVariable Long id) {
		return service.read(id);
	}

	@PutMapping("/{id}")
	public OrderItens update(@PathVariable Long id, @RequestBody OrderItens orderItens) {
		return service.update(id, orderItens);
	}

	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id) {
		service.delete(id);
	}

	@GetMapping("/list")
	public List<OrderItens> list() {
		return service.list();

	}
   public OrderItens close(@PathVariable Long id) {
	   return service.close(id);
	   
   }
   
}
