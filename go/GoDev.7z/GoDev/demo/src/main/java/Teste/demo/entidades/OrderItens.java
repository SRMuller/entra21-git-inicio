package Teste.demo.entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "order_itens")
public class OrderItens {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long id;
	private  double quantity;
	@Column(name = "total_value" )
	private double totalValue;
	
	@OneToOne
	@JoinColumn(name = "item_id", unique = true)
	private Item item;
	
	@ManyToOne
	@JoinColumn(name = "purchaseOrder_id")
	private PurchaseOrder purchaseOrder;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(double totalValue) {
		this.totalValue = totalValue;
	}
	
	

}
