package Teste.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Teste.demo.Repository.PurchaseOrderRepository;
import Teste.demo.entidades.PurchaseOrder;


@Service
public class PurchaseOrederservice {
	
	@Autowired
	private PurchaseOrderRepository repository;
	
	
	public List<PurchaseOrder> list(){
         return repository.findAll();
}
	
	public PurchaseOrder insert(PurchaseOrder purchaseOrder) {
		return repository.save(purchaseOrder);
	}

	public PurchaseOrder update(Long id, PurchaseOrder purchaseOrder) {
		
		PurchaseOrder updatedPurchaseOrder = repository.findById(id).orElseThrow(()->new RuntimeException("Item não encontrado"));
		updatedPurchaseOrder.setDate(purchaseOrder.getDate());
		updatedPurchaseOrder.setNumber(purchaseOrder.getNumber());
		updatedPurchaseOrder.setPercentualDiscont(purchaseOrder.getPercentualDiscont());
		updatedPurchaseOrder.setTotalvalue(purchaseOrder.getTotalvalue());
		return repository.save(updatedPurchaseOrder);
	}

	public void delete(Long id) {
		repository.deleteById(id);
		}
	
	public PurchaseOrder read(Long id) {
		return repository.findById(id).orElseThrow(()->new RuntimeException("Item não encontrado"));
	}
	
}
