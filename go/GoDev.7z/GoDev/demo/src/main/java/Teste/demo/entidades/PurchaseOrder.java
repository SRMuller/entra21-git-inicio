package Teste.demo.entidades;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "purchase_order")
public class PurchaseOrder {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;
	private int number;
	private Date date;
	@Column(name = "percentual_discont" )
	private double percentualDiscont;
	@Column(name = "total_value" )
	private double totalValue;

	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getPercentualDiscont() {
		return percentualDiscont;
	}
	public void setPercentualDiscont(double percentualDiscont) {
		this.percentualDiscont = percentualDiscont;
	}
	public double getTotalvalue() {
		return totalValue;
	}
	public void setTotalvalue(double totalvalue) {
		this.totalValue = totalvalue;
	}
	
	
}
