package Teste.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Teste.demo.Repository.ItemReposytory;
import Teste.demo.entidades.Item;

@Service
public class ItemService {

	@Autowired
	private ItemReposytory repository;

	public List<Item> list() {
		return repository.findAll();
	}
	public Item insert(Item item) {
		return repository.save(item);
	}
	public void delete (Long id) {
		repository.deleteById(id);
	}
	public Item update(Long id, Item item) {
		Item updatedItem = repository.findById(id).orElseThrow(()->new RuntimeException("Item não encontrado"));
		updatedItem.setDescription(item.getDescription());
		updatedItem.setValue(item.getValue());
		updatedItem.setType(item.getType());
		return repository.save(updatedItem);
	}
	
	public Item  read (Long id) {
		return repository.findById(id).orElseThrow(()->new RuntimeException("Item não encontrado"));
	}
	
	

}
