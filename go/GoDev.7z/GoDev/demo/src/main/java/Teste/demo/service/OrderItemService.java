package Teste.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Teste.demo.Repository.OrderItemRepository;
import Teste.demo.entidades.OrderItens;

@Service
public class OrderItemService {

	@Autowired
	private OrderItemRepository repository;

	public OrderItens insert(OrderItens orderItens) {
		
		return repository.save(orderItens);
	}

	public OrderItens read(Long id) {
		return repository.findById(id).orElseThrow(() -> new RuntimeException("Item não encontrado"));
	}

	public OrderItens update(Long id, OrderItens orderItens) {
		OrderItens updatedOrderItens = repository.findById(id)
				.orElseThrow(() -> new RuntimeException("Item não encontrado"));
		updatedOrderItens.setId(orderItens.getId());
		updatedOrderItens.setQuantity(orderItens.getQuantity());
		return repository.save(updatedOrderItens);
	}

	public void delete(Long id) {
		repository.deleteById(id);

	}

	public List<OrderItens> list() {
		return repository.findAll();
	}

	public OrderItens close(Long id) {
		 
		return repository.findById(id).orElseThrow(() -> new RuntimeException("Item não encontrado"));
		
	}

}
