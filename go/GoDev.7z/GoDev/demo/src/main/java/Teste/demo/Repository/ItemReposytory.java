package Teste.demo.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Teste.demo.entidades.Item;

@Repository
public interface ItemReposytory extends JpaRepository<Item, Long>  {

	
}
