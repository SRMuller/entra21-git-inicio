package com.entra21.moduloCompras.model.dto;

import lombok.Data;

@Data
public class OrdemCompraDTO {
    private Long id;
}
