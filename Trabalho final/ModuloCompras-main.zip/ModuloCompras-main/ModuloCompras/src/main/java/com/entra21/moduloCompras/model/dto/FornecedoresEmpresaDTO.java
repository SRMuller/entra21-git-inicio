package com.entra21.moduloCompras.model.dto;

import lombok.Data;

@Data
public class FornecedoresEmpresaDTO {
    private Long id;
    private Boolean ativo;
}