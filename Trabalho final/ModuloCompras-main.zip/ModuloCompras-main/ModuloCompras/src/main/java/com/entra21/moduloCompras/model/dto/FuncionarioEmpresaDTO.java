package com.entra21.moduloCompras.model.dto;

import lombok.Data;

@Data
public class FuncionarioEmpresaDTO {
    private Long id;
    private Boolean ativo;

}
