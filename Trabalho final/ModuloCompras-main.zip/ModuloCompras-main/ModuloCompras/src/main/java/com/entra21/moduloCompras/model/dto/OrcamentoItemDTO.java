package com.entra21.moduloCompras.model.dto;

import lombok.Data;

@Data
public class OrcamentoItemDTO {
    private Long id;
    private Double valorMaximo;

}
