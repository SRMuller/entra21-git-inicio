package com.entra21.moduloCompras.model.dto;

import lombok.Data;

@Data
public class OrcamentoDTO {
    private Long id;
    private String descricao;
}