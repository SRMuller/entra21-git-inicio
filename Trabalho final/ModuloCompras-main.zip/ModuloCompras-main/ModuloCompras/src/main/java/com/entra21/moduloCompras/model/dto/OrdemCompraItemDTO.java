package com.entra21.moduloCompras.model.dto;

import lombok.Data;

@Data
public class OrdemCompraItemDTO {
    private Long id;
    private Double quantidade;
}